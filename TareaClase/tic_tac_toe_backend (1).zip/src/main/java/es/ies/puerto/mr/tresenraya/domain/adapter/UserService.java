// UserService.java - Implementación en proceso
