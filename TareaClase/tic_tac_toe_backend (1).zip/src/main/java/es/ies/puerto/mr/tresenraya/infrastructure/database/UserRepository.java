// UserRepository.java - Implementación en proceso
