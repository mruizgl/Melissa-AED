// UserController.java - Implementación en proceso
