// UserRepositoryPort.java - Implementación en proceso
