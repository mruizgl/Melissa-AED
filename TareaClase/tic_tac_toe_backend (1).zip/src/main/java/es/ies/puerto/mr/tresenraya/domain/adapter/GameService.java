// GameService.java - Implementación en proceso
