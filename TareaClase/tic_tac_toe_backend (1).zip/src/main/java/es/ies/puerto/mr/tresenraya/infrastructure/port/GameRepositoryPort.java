// GameRepositoryPort.java - Implementación en proceso
