// GameRepository.java - Implementación en proceso
