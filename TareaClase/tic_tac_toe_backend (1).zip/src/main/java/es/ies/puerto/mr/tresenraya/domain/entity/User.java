// User.java - Implementación en proceso
