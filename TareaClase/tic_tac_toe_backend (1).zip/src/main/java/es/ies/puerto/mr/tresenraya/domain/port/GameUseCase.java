// GameUseCase.java - Implementación en proceso
