// GameRepositoryAdapter.java - Implementación en proceso
