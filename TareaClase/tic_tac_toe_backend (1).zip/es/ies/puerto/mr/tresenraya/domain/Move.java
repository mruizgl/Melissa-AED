// Move.java - Implementación pendiente
