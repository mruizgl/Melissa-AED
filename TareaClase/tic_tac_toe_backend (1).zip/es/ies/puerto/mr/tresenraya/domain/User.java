// User.java - Implementación pendiente
