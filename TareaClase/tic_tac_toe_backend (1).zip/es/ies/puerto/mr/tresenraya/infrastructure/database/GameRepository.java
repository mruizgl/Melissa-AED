// GameRepository.java - Implementación pendiente
