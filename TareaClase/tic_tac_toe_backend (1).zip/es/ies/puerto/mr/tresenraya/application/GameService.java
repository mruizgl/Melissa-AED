// GameService.java - Implementación pendiente
