// GameRepositoryPort.java - Implementación pendiente
