// GameUseCase.java - Implementación pendiente
