// GameRepositoryAdapter.java - Implementación pendiente
