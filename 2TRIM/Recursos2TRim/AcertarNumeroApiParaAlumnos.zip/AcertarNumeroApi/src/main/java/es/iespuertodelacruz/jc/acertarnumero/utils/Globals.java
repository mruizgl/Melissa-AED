package es.iespuertodelacruz.jc.acertarnumero.utils;

public class Globals {

	public static final int MINIMO = 1000;
	public static final int MAXIMO = 9000;
}
