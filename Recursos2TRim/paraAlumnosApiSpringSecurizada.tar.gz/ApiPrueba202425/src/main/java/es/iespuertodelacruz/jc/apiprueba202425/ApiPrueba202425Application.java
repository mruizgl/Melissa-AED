package es.iespuertodelacruz.jc.apiprueba202425;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
//@EnableScheduling
public class ApiPrueba202425Application {

	public static void main(String[] args) {
		SpringApplication.run(ApiPrueba202425Application.class, args);
	}

}
